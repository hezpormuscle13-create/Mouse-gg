package android.view;
public final class InputMonitor {
    public InputChannel getInputChannel() { throw new RuntimeException("stub"); }
    public void pilferPointers() { throw new RuntimeException("stub"); }
    public void dispose() { throw new RuntimeException("stub"); }
}
