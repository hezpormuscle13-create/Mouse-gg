package com.giuthang

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: View? = null
    private val filter = StraightFilter()
    private val handler = Handler(Looper.getMainLooper())

    private var active = false
    private var downTime = 0L
    private var lastX = 0f
    private var lastY = 0f

    // Nếu mất sự kiện (hệ thống không gửi tiếp) thì tự nhả tay để không bị kẹt
    private val watchdog = Runnable { finishGesture() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Cfg.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val v = View(this)
        v.setOnTouchListener { _, ev -> onTouch(ev); true }
        view = v
        wm.addView(v, lp)
        Cfg.enabled = true
    }

    private fun setTouchable(t: Boolean) {
        val f = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        lp.flags = if (t) lp.flags and f.inv() else lp.flags or f
        try { view?.let { wm.updateViewLayout(it, lp) } } catch (_: Throwable) {}
    }

    private fun onTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                active = true
                downTime = SystemClock.uptimeMillis()
                lastX = ev.rawX; lastY = ev.rawY
                filter.start(lastX, lastY)
                setTouchable(false) // để cảm ứng tiêm vào xuyên xuống app bên dưới
                Shell.touch(MotionEvent.ACTION_DOWN, downTime, lastX, lastY)
                arm()
            }
            MotionEvent.ACTION_MOVE -> if (active) {
                val dx = ev.rawX - ev.x; val dy = ev.rawY - ev.y
                for (i in 0 until ev.historySize) {
                    filter.move(ev.getHistoricalX(i) + dx, ev.getHistoricalY(i) + dy)
                }
                filter.move(ev.rawX, ev.rawY)
                lastX = filter.outX; lastY = filter.outY
                Shell.touch(MotionEvent.ACTION_MOVE, downTime, lastX, lastY)
                arm()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> finishGesture()
        }
    }

    private fun arm() { handler.removeCallbacks(watchdog); handler.postDelayed(watchdog, 300) }

    private fun finishGesture() {
        handler.removeCallbacks(watchdog)
        if (!active) return
        active = false
        Shell.touch(MotionEvent.ACTION_UP, downTime, lastX, lastY)
        setTouchable(true)
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gt", "Giữ thẳng", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "gt")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Giữ thẳng đang bật")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        handler.removeCallbacks(watchdog)
        if (active) Shell.touch(MotionEvent.ACTION_UP, downTime, lastX, lastY)
        view?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        view = null
        Cfg.enabled = false
        super.onDestroy()
    }
}
