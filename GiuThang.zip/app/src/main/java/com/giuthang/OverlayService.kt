package com.giuthang

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: View? = null
    private val filter = StraightFilter()
    private val handler = Handler(Looper.getMainLooper())

    // 0 = rảnh, 1 = đang đợi lớp phủ thu nhỏ xong, 2 = đang tiêm cảm ứng
    private var phase = 0
    private var upPending = false
    private var downTime = 0L
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f

    private val ready = Runnable {
        if (phase != 1) return@Runnable
        phase = 2
        Shell.touch(MotionEvent.ACTION_DOWN, downTime, startX, startY)
        if (lastX != startX || lastY != startY)
            Shell.touch(MotionEvent.ACTION_MOVE, downTime, lastX, lastY)
        if (upPending) finishGesture()
    }
    // chỉ là lưới an toàn nếu không bao giờ nhận được UP
    private val watchdog = Runnable { finishGesture() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Cfg.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val v = View(this)
        v.setOnTouchListener { _, ev -> onTouch(ev); true }
        view = v
        wm.addView(v, lp)
        Cfg.enabled = true
    }

    /** true = thu lớp phủ còn 1x1 px (ngón tay thật vẫn được giữ), false = phủ lại toàn màn hình */
    private fun shrink(t: Boolean) {
        if (t) { lp.width = 1; lp.height = 1 }
        else { lp.width = WindowManager.LayoutParams.MATCH_PARENT; lp.height = WindowManager.LayoutParams.MATCH_PARENT }
        lp.x = 0; lp.y = 0
        try { view?.let { wm.updateViewLayout(it, lp) } } catch (_: Throwable) {}
    }

    private fun onTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (phase != 0) finishGesture()
                phase = 1; upPending = false
                downTime = SystemClock.uptimeMillis()
                startX = ev.rawX; startY = ev.rawY
                lastX = startX; lastY = startY
                filter.start(startX, startY)
                shrink(true)
                handler.postDelayed(ready, 45) // đợi hệ thống áp dụng kích thước mới rồi mới tiêm
                arm()
            }
            MotionEvent.ACTION_MOVE -> if (phase != 0) {
                val dx = ev.rawX - ev.x; val dy = ev.rawY - ev.y
                for (i in 0 until ev.historySize)
                    filter.move(ev.getHistoricalX(i) + dx, ev.getHistoricalY(i) + dy)
                filter.move(ev.rawX, ev.rawY)
                lastX = filter.outX; lastY = filter.outY
                if (phase == 2) Shell.touch(MotionEvent.ACTION_MOVE, downTime, lastX, lastY)
                arm()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (phase == 1) upPending = true else finishGesture()
            }
        }
    }

    private fun arm() { handler.removeCallbacks(watchdog); handler.postDelayed(watchdog, 8000) }

    private fun finishGesture() {
        handler.removeCallbacks(watchdog)
        handler.removeCallbacks(ready)
        if (phase == 0) return
        if (phase == 1) Shell.touch(MotionEvent.ACTION_DOWN, downTime, startX, startY)
        Shell.touch(MotionEvent.ACTION_UP, downTime, lastX, lastY)
        phase = 0; upPending = false
        shrink(false)
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gt", "Giữ thẳng", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "gt")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Giữ thẳng đang bật")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (phase != 0) Shell.touch(MotionEvent.ACTION_UP, downTime, lastX, lastY)
        view?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        view = null
        Cfg.enabled = false
        super.onDestroy()
    }
}
