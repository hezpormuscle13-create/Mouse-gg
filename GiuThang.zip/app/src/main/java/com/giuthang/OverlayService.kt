package com.giuthang

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.InputChannel
import android.view.InputDevice
import android.view.InputEvent
import android.view.InputEventReceiver
import android.view.InputMonitor
import android.view.MotionEvent
import android.widget.Toast

/**
 * Không còn dùng lớp phủ chắn cảm ứng. Thay vào đó dùng InputMonitor (qua Shizuku):
 * nhận cảm ứng thật -> chặn nó không tới app -> tiêm lại nét đã làm mượt/thẳng nhẹ.
 */
class OverlayService : Service() {
    private var thread: HandlerThread? = null
    private var monitor: InputMonitor? = null
    private var receiver: InputEventReceiver? = null
    private val filter = StraightFilter()

    private var tracking = false
    private var downTime = 0L
    private var lastX = 0f
    private var lastY = 0f

    private inner class Recv(ch: InputChannel, l: Looper) : InputEventReceiver(ch, l) {
        override fun onInputEvent(event: InputEvent) {
            try {
                if (event is MotionEvent && event.deviceId != -1 &&
                    (event.source and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
                ) handle(event)
            } catch (_: Throwable) {
            } finally {
                finishInputEvent(event, true)
            }
        }
    }

    private fun handle(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (tracking) end()
                tracking = true
                downTime = SystemClock.uptimeMillis()
                lastX = e.rawX; lastY = e.rawY
                filter.start(lastX, lastY)
                try { monitor?.pilferPointers() } catch (_: Throwable) {} // chặn cảm ứng thật tới app
                Shell.touch(MotionEvent.ACTION_DOWN, downTime, lastX, lastY)
            }
            MotionEvent.ACTION_MOVE -> if (tracking) {
                val dx = e.rawX - e.x; val dy = e.rawY - e.y
                for (i in 0 until e.historySize)
                    filter.move(e.getHistoricalX(i) + dx, e.getHistoricalY(i) + dy)
                filter.move(e.rawX, e.rawY)
                lastX = filter.outX; lastY = filter.outY
                Shell.touch(MotionEvent.ACTION_MOVE, downTime, lastX, lastY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (tracking) end()
        }
    }

    private fun end() {
        tracking = false
        Shell.touch(MotionEvent.ACTION_UP, downTime, lastX, lastY)
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Cfg.load(this)
        startFg()
        try {
            val t = HandlerThread("giuthang").also { it.start() }
            thread = t
            val m = Shell.createMonitor()
            monitor = m
            receiver = Recv(m.inputChannel, t.looper)
            Cfg.enabled = true
            Cfg.error = ""
        } catch (e: Throwable) {
            val msg = "Lỗi: ${e.message}"
            Cfg.error = msg + "\n" + e.stackTrace.take(4).joinToString("\n") { "  at " + it }
            Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
            stopSelf()
        }
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gt", "Giữ thẳng", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "gt")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Giữ thẳng đang bật")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        if (tracking) end()
        try { receiver?.dispose() } catch (_: Throwable) {}
        try { monitor?.dispose() } catch (_: Throwable) {}
        thread?.quitSafely()
        Cfg.enabled = false
        super.onDestroy()
    }
}
