package com.giuthang

import android.content.Context

object Cfg {
    @Volatile var smooth = 60      // 0..100
    @Volatile var snap = 40        // 0..100 (%)
    @Volatile var angle = 25       // 5..45 (độ)
    @Volatile var thick = 5        // 1..20
    @Volatile var mode = 0         // 0 tự động, 1 ngang, 2 dọc
    @Volatile var enabled = false

    fun load(c: Context) {
        val p = c.getSharedPreferences("cfg", 0)
        smooth = p.getInt("smooth", smooth); snap = p.getInt("snap", snap)
        angle = p.getInt("angle", angle); thick = p.getInt("thick", thick)
        mode = p.getInt("mode", mode)
    }

    fun save(c: Context) {
        c.getSharedPreferences("cfg", 0).edit()
            .putInt("smooth", smooth).putInt("snap", snap).putInt("angle", angle)
            .putInt("thick", thick).putInt("mode", mode).apply()
    }
}
