package com.giuthang

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

/** Làm mượt + kéo nhẹ về đường thẳng (không khóa cứng). */
class StraightFilter {
    private var sx = 0f; private var sy = 0f
    private var fx = 0f; private var fy = 0f
    var outX = 0f; private set
    var outY = 0f; private set

    fun start(x: Float, y: Float) { sx = x; sy = y; fx = x; fy = y; outX = x; outY = y }

    fun move(x: Float, y: Float) {
        var tx = x; var ty = y
        val dx = x - sx; val dy = y - sy
        if (hypot(dx, dy) > 30f && Cfg.snap > 0) {
            val ang = Math.toDegrees(atan2(abs(dy), abs(dx)).toDouble()).toFloat() // 0..90 so với trục ngang
            val horizontal = when (Cfg.mode) { 1 -> true; 2 -> false; else -> ang < 45f }
            val off = if (horizontal) ang else 90f - ang
            val limit = if (Cfg.mode == 0) Cfg.angle.toFloat() else 90f
            if (off <= limit) {
                val w = (Cfg.snap / 100f) * (1f - off / limit) // càng gần trục càng hít, mép = 0 nên không giật
                if (horizontal) ty = y - dy * w else tx = x - dx * w
            }
        }
        // làm mượt (EMA): độ mượt cao thì trễ nhiều hơn
        val alpha = (1f - 0.9f * Cfg.smooth / 100f).coerceIn(0.08f, 1f)
        fx += (tx - fx) * alpha
        fy += (ty - fy) * alpha
        outX = fx; outY = fy
    }
}
