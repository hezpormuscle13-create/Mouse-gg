package com.giuthang

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import rikka.shizuku.Shizuku

class DrawView(c: Context) : View(c) {
    private val paths = ArrayList<Path>()
    private var cur: Path? = null
    private val grid = Paint().apply { color = 0xFF2A2A2A.toInt(); strokeWidth = 1f }
    private val pen = Paint().apply {
        color = Color.WHITE; style = Paint.Style.STROKE; isAntiAlias = true
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    fun clear() { paths.clear(); cur = null; invalidate() }
    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF1A1A1A.toInt())
        val s = 112f * resources.displayMetrics.density / 3f * 1.0f
        var x = 0f; while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), grid); x += s }
        var y = 0f; while (y < height) { c.drawLine(0f, y, width.toFloat(), y, grid); y += s }
        pen.strokeWidth = Cfg.thick * resources.displayMetrics.density / 2f
        for (p in paths) c.drawPath(p, pen)
        cur?.let { c.drawPath(it, pen) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                cur = Path().apply { moveTo(e.x, e.y) }
            }
            MotionEvent.ACTION_MOVE -> cur?.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { cur?.let { paths.add(it) }; cur = null }
        }
        invalidate(); return true
    }
}

class MainActivity : Activity() {
    private lateinit var toggle: Button
    private lateinit var status: TextView
    private lateinit var draw: DrawView
    private val modeBtns = ArrayList<Button>()
    private val pkg get() = packageName

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(18).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(8) }
    }

    private fun slider(root: LinearLayout, label: String, min: Int, max: Int, get: () -> Int,
                       set: (Int) -> Unit, suffix: String) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = TextView(this).apply { text = label; setTextColor(Color.WHITE); textSize = 16f }
        val v = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.END
            text = "${get()}$suffix"
        }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = get() - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    set(p + min); v.text = "${p + min}$suffix"; Cfg.save(this@MainActivity); draw.invalidate()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row.addView(t, LinearLayout.LayoutParams(dp(110), -2))
        row.addView(sb, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(v, LinearLayout.LayoutParams(dp(56), -2))
        root.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Cfg.load(this)
        window.statusBarColor = 0xFF101010.toInt()
        window.navigationBarColor = 0xFF101010.toInt()

        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF121212.toInt()) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(root)

        draw = DrawView(this)
        root.addView(draw, LinearLayout.LayoutParams(-1, dp(240)))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(30)) }
        root.addView(body)

        toggle = btn("", 0xFF555555.toInt()) { onToggle() }
        body.addView(toggle)

        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        modes.addView(TextView(this).apply { text = "Kiểu"; setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 0, dp(10), 0) })
        listOf("Tự động", "Ngang", "Dọc").forEachIndexed { i, n ->
            val m = btn(n, 0xFF2A2A2A.toInt()) { Cfg.mode = i; Cfg.save(this); refresh() }
            m.layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f).apply { leftMargin = dp(4); topMargin = dp(8) }
            modeBtns.add(m); modes.addView(m)
        }
        body.addView(modes)

        slider(body, "Độ mượt", 0, 100, { Cfg.smooth }, { Cfg.smooth = it }, "")
        slider(body, "Độ hít thẳng", 0, 100, { Cfg.snap }, { Cfg.snap = it }, "%")
        slider(body, "Góc hút", 5, 45, { Cfg.angle }, { Cfg.angle = it }, "°")
        slider(body, "Độ dày nét", 1, 20, { Cfg.thick }, { Cfg.thick = it }, "")

        body.addView(btn("Xóa hết", 0xFFD32F2F.toInt()) { draw.clear() })

        status = TextView(this).apply { setTextColor(0xFFDDDDDD.toInt()); textSize = 15f; setPadding(0, dp(18), 0, dp(6)) }
        body.addView(TextView(this).apply { text = "Quyền cần cấp"; setTextColor(Color.WHITE); textSize = 18f; setTypeface(typeface, Typeface.BOLD) })
        body.addView(status)

        val grey = 0xFF37474F.toInt(); val blue = 0xFF1565C0.toInt()
        body.addView(btn("1. Mở Shizuku", grey) {
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
                ?: Toast.makeText(this, "Chưa cài Shizuku", Toast.LENGTH_SHORT).show()
        })
        body.addView(btn("2. Cấp quyền Shizuku cho app này", blue) {
            try {
                if (!Shizuku.pingBinder()) toast("Shizuku chưa chạy")
                else Shizuku.requestPermission(100)
            } catch (_: Throwable) { toast("Shizuku chưa chạy") }
        })
        body.addView(btn("3. Tự cấp quyền còn lại bằng Shizuku", blue) { autoGrant() })

        setContentView(scroll)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun autoGrant() {
        if (!Shell.ready()) { toast("Cần bật Shizuku và cấp quyền trước"); return }
        Thread {
            Shell.run("appops set $pkg SYSTEM_ALERT_WINDOW allow")
            Shell.run("appops set $pkg RUN_ANY_IN_BACKGROUND allow")
            Shell.run("dumpsys deviceidle whitelist +$pkg")
            Shell.run("pm grant $pkg android.permission.POST_NOTIFICATIONS")
            runOnUiThread { refresh(); toast("Đã cấp quyền") }
        }.start()
    }

    private fun onToggle() {
        if (Cfg.enabled) { stopService(Intent(this, OverlayService::class.java)); toggle.postDelayed({ refresh() }, 200); return }
        if (!Shell.ready()) { toast("Cần Shizuku chạy và đã cấp quyền"); return }
        startForegroundService(Intent(this, OverlayService::class.java))
        toggle.postDelayed({ refresh() }, 300)
    }

    private fun tick(ok: Boolean) = if (ok) "✓" else "✗"

    private fun refresh() {
        val run = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        status.text = listOf(
            tick(Settings.canDrawOverlays(this)) + " Hiển thị trên ứng dụng khác",
            tick(run) + " Shizuku đang chạy",
            tick(Shell.ready()) + " Đã cấp quyền Shizuku",
            tick(getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(pkg)) + " Không tối ưu pin"
        ).joinToString("\n")
        toggle.text = if (Cfg.enabled) "Giữ thẳng: BẬT" else "Giữ thẳng: TẮT"
        (toggle.background as android.graphics.drawable.GradientDrawable)
            .setColor(if (Cfg.enabled) 0xFF2E7D32.toInt() else 0xFF555555.toInt())
        modeBtns.forEachIndexed { i, m ->
            (m.background as android.graphics.drawable.GradientDrawable)
                .setColor(if (Cfg.mode == i) 0xFF2E7D32.toInt() else 0xFF2A2A2A.toInt())
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }
}
