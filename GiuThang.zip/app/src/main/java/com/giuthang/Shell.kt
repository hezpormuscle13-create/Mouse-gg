package com.giuthang

import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.InputMonitor
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

object Shell {
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun run(cmd: String): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        p.waitFor() == 0
    } catch (_: Throwable) { false }

    private var im: Any? = null
    private var inject: Method? = null
    private var imClass: Class<*>? = null

    private fun init(): Boolean {
        if (inject != null) return true
        return try {
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            imClass = Class.forName("android.hardware.input.IInputManager")
            inject = imClass!!.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            true
        } catch (_: Throwable) { false }
    }

    /** Tạo "InputMonitor" bằng quyền shell: nhận mọi cảm ứng thật và có thể chặn chúng không tới app. */
    fun createMonitor(): InputMonitor {
        if (!init()) throw IllegalStateException("Không khởi tạo được dịch vụ input qua Shizuku")
        val ms = imClass!!.methods.filter { it.name == "monitorGestureInput" }
        if (ms.isEmpty()) throw IllegalStateException("Máy không có monitorGestureInput (Android ${Build.VERSION.SDK_INT})")
        var last: Throwable? = null
        for (m in ms) {
            // tự điền tham số theo kiểu: IBinder -> Binder, String -> tên, int -> 0 (màn hình chính)
            val args = m.parameterTypes.map { t ->
                when (t) {
                    IBinder::class.java -> Binder()
                    String::class.java -> "GiuThang"
                    Int::class.javaPrimitiveType -> 0
                    Long::class.javaPrimitiveType -> 0L
                    Boolean::class.javaPrimitiveType -> false
                    else -> null
                }
            }.toTypedArray()
            try {
                return m.invoke(im, *args) as InputMonitor
            } catch (e: InvocationTargetException) {
                last = e.targetException ?: e
            } catch (e: Throwable) {
                last = e
            }
        }
        val sig = ms.joinToString(" | ") { m -> m.parameterTypes.joinToString(",") { it.simpleName } }
        val c = last?.cause
        throw IllegalStateException(
            "${last?.javaClass?.simpleName}: ${last?.message}" +
            (if (c != null) " / ${c.javaClass.simpleName}: ${c.message}" else "") +
            " [Android ${Build.VERSION.SDK_INT}, $sig]"
        )
    }

    fun touch(action: Int, downTime: Long, x: Float, y: Float): Boolean {
        if (!init()) return false
        val pp = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0; toolType = MotionEvent.TOOL_TYPE_FINGER
        })
        val pc = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x; this.y = y; pressure = 1f; size = 1f
        })
        // deviceId = -1 (thiết bị ảo) để phân biệt với ngón tay thật
        val e = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, 1, pp, pc,
            0, 0, 1f, 1f, -1, 0, InputDevice.SOURCE_TOUCHSCREEN, 0)
        return try {
            inject!!.invoke(im, e, 0); true
        } catch (_: Throwable) { false } finally { e.recycle() }
    }
}
